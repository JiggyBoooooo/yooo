/* ============================================================
   SportaBiedrs - application logic (v4)
   ============================================================ */
'use strict';

function safeGet(key, fallback){ try{ const raw = localStorage.getItem(key); if(raw===null) return fallback; const p = JSON.parse(raw); return (p===null||p===undefined)?fallback:p; }catch(e){ return fallback; } }
function safeSet(key, value){ try{ localStorage.setItem(key, JSON.stringify(value)); return true; }catch(e){ return false; } }
function escapeHtml(str){ return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function euro(n){ return n.toFixed(2).replace('.', ',') + ' \u20ac'; }

let toastTimer = null;
function showToast(msg){
  const el = document.getElementById('toast');
  if(!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> el.classList.remove('show'), 3600);
}

/* ---------------- Cookie consent ---------------- */
const COOKIE_KEY = 'sb_cookie_consent_v4';
function initCookieBanner(){
  const consent = safeGet(COOKIE_KEY, null);
  if(!consent) showCookieBanner();
}
function showCookieBanner(){
  document.getElementById('cookieBanner').style.display = 'flex';
  document.body.classList.add('cookie-open');
}
function hideCookieBanner(){
  document.getElementById('cookieBanner').style.display = 'none';
  document.body.classList.remove('cookie-open');
}
function setCookieConsent(level){
  safeSet(COOKIE_KEY, {level, analytics: level === 'all'});
  hideCookieBanner();
  showToast(level === 'all' ? 'Sīkdatnes pieņemtas.' : 'Saglabātas tikai nepieciešamās sīkdatnes.');
}
function saveCookieSettings(){
  const analytics = document.getElementById('ckAnalytics').checked;
  safeSet(COOKIE_KEY, {level: analytics ? 'all' : 'necessary', analytics});
  hideCookieBanner();
  closeModal('cookieSettingsModal');
  showToast('Sīkdatņu izvēle saglabāta.');
}

/* ---------------- Modals ---------------- */
function openModal(id){ document.getElementById(id).classList.add('open'); }
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
document.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape'){
    ['loginModal','registerModal','checkoutModal','cookieSettingsModal'].forEach(closeModal);
    toggleCart(false);
    closeChatbotPanel();
  }
});
function fakeAuth(type){
  const label = type === 'login' ? 'Ienākšana' : 'Reģistrācija';
  showToast(label + ': veiksmīga (demo). Reālai autentifikācijai nepieciešams serveris.');
  closeModal('loginModal'); closeModal('registerModal');
}

/* ---------------- Partner finder ---------------- */
const NAMES = ["Kārlis","Elīna","Roberts","Anna","Jānis","Laura","Mareks","Dita","Artūrs","Sabīne","Ralfs","Zane","Emīls","Līga","Toms"];
const LEVELS = ["Iesācējs","Vidējs","Pieredzējis","Profesionālis"];
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function genPartners(sport, city, level){
  const sports = sport ? [sport] : ["Teniss","Padelis","Basketbols","Futbols","Skriešana","Velosports","Peldēšana","Bokss / MMA","Volejbols","Hokejs","Disku golfs"];
  const cities = city ? [city] : ["Rīga","Jūrmala","Liepāja","Daugavpils","Jelgava","Sigulda"];
  const levels = level ? [level] : LEVELS;
  return Array.from({length:6}, ()=>({ name: pick(NAMES), sport: pick(sports), city: pick(cities), level: pick(levels) }));
}
function findPartners(){
  const sport = document.getElementById('fSport').value;
  const city = document.getElementById('fCity').value;
  const level = document.getElementById('fLevel').value;
  const box = document.getElementById('partnerResults');
  const list = genPartners(sport, city, level);
  box.innerHTML = list.map(p => `
    <div class="partner-card">
      <div class="avatar">${escapeHtml(p.name[0])}</div>
      <div>
        <div class="p-name">${escapeHtml(p.name)}</div>
        <div class="p-meta">${escapeHtml(p.sport)} \u00b7 ${escapeHtml(p.city)}</div>
        <span class="p-badge">${escapeHtml(p.level)}</span>
      </div>
      <a class="msg-btn" href="#messages" onclick="go('messages')">Rakstīt \u2192</a>
    </div>`).join('');
}
function go(id){ document.getElementById(id).scrollIntoView({behavior:'smooth', block:'start'}); }

/* ---------------- Sport icon set (used on map pins and venue list) ---------------- */
const SPORT_ICONS = {
  tennis: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M4 7c3 3 3 7 0 10M20 7c-3 3-3 7 0 10"/></svg>',
  padel: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="2" width="12" height="14" rx="6"/><line x1="12" y1="16" x2="12" y2="22"/></svg>',
  basketball: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18M5 5c3 3 3 13 0 16M19 5c-3 3-3 13 0 16"/></svg>',
  football: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7l4 3-1.5 5h-5L8 10z"/></svg>',
  hockey: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20l5-14 4 1-4 12z"/><circle cx="18" cy="17" r="2"/></svg>',
  volleyball: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 3c3 3 3 15 0 18M4 9c4 1 12 1 16 0M4 15c4-1 12-1 16 0"/></svg>',
  discgolf: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="9" ry="4"/></svg>',
  boxing: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13V8a3 3 0 0 1 6 0v3M11 13V6a3 3 0 0 1 6 0v9a5 5 0 0 1-5 5H9l-4-4"/></svg>',
  fitness: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 7v10M18 7v10M2 12h4M18 12h4M6 12h12"/></svg>',
  swimming: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12c2-2 4-2 6 0s4 2 6 0 4-2 6 0M2 17c2-2 4-2 6 0s4 2 6 0 4-2 6 0"/><circle cx="17" cy="6" r="2"/></svg>',
  running: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="15" cy="5" r="2"/><path d="M6 20l3-5 3 2 2-4 4 2M9 15l-2-4 4-3 3 3 3-1"/></svg>',
  cycling: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="17" r="3.5"/><circle cx="18" cy="17" r="3.5"/><path d="M6 17l4-9h4l4 9M8 8h4"/></svg>'
};

/* ---------------- Venue data (map + list) ---------------- */
const VENUES = [
  {"name":"Lielupe Padel Riga","sportKey":"padel","sport":"Padelis","city":"Rīga","address":"Bauskas iela 58, Rīga","lat":56.9186,"lng":24.1315,"price":"18 \u20ac/h","priceValue":18,"rating":4.8,"reviews":212,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Lielupe+Padel+Riga+R%C4%ABga"},
  {"name":"Padel House Riga","sportKey":"padel","sport":"Padelis","city":"Rīga","address":"Duntes iela 6, Rīga","lat":56.9598,"lng":24.1472,"price":"20 \u20ac/h","priceValue":20,"rating":4.7,"reviews":156,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Padel+House+Riga"},
  {"name":"Lattelecom Tenisa centrs","sportKey":"tennis","sport":"Teniss","city":"Rīga","address":"Vienības gatve 1, Rīga","lat":56.9302,"lng":24.0982,"price":"25 \u20ac/h","priceValue":25,"rating":4.6,"reviews":340,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Lattelecom+Tenisa+centrs+Riga"},
  {"name":"Jelgavas tenisa klubs","sportKey":"tennis","sport":"Teniss","city":"Jelgava","address":"Pulkveža Oskara Kalpaka iela 8, Jelgava","lat":56.6511,"lng":23.7274,"price":"16 \u20ac/h","priceValue":16,"rating":4.5,"reviews":61,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Jelgavas+tenisa+klubs"},
  {"name":"Riga Basketball Arena (Elerte)","sportKey":"basketball","sport":"Basketbols","city":"Rīga","address":"Hanzas iela 4, Rīga","lat":56.955,"lng":24.1035,"price":"30 \u20ac/h","priceValue":30,"rating":4.4,"reviews":88,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Riga+Basketball+Arena"},
  {"name":"Skonto futbola manēža","sportKey":"football","sport":"Futbols","city":"Rīga","address":"Kandavas iela 27, Rīga","lat":56.9686,"lng":24.0661,"price":"40 \u20ac/h","priceValue":40,"rating":4.5,"reviews":97,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Skonto+futbola+manēža+Riga"},
  {"name":"Arena Rīga Sporta klubs","sportKey":"hockey","sport":"Hokejs","city":"Rīga","address":"Skanstes iela 21, Rīga","lat":56.96,"lng":24.1225,"price":"70 \u20ac/h","priceValue":70,"rating":4.6,"reviews":145,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Arena+Riga+Sporta+klubs"},
  {"name":"Volejbola centrs Ozolciems","sportKey":"volleyball","sport":"Volejbols","city":"Rīga","address":"Ozolciema iela 4, Rīga","lat":56.9345,"lng":24.0246,"price":"22 \u20ac/h","priceValue":22,"rating":4.5,"reviews":47,"verified":false,"gmaps":"https://www.google.com/maps/search/?api=1&query=Volejbola+centrs+Ozolciems"},
  {"name":"Kipsalas disku golfa parks","sportKey":"discgolf","sport":"Disku golfs","city":"Rīga","address":"Kipsalas iela, Rīga","lat":56.9439,"lng":24.0838,"price":"Bezmaksas","priceValue":0,"rating":4.7,"reviews":96,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Kipsalas+disku+golfa+parks"},
  {"name":"Bulldozer Boxing Riga","sportKey":"boxing","sport":"Bokss / MMA","city":"Rīga","address":"Lāčplēša iela 87, Rīga","lat":56.9498,"lng":24.1421,"price":"12 \u20ac/treniņš","priceValue":12,"rating":4.9,"reviews":274,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Bulldozer+Boxing+Riga"},
  {"name":"Tridens Fitness Elizabete","sportKey":"fitness","sport":"Fitnesa zāle","city":"Rīga","address":"Elizabetes iela 21a, Rīga","lat":56.9535,"lng":24.1156,"price":"35 \u20ac/mēn.","priceValue":2,"rating":4.5,"reviews":512,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Tridens+Fitness+Elizabete"},
  {"name":"MyFitness Origo","sportKey":"fitness","sport":"Fitnesa zāle","city":"Rīga","address":"Stacijas laukums 2, Rīga","lat":56.9468,"lng":24.117,"price":"39 \u20ac/mēn.","priceValue":2,"rating":4.3,"reviews":890,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=MyFitness+Origo+Riga"},
  {"name":"Rimi Olimpiskais centrs (peldbaseins)","sportKey":"swimming","sport":"Peldēšana","city":"Rīga","address":"Grostonas iela 6b, Rīga","lat":56.9584,"lng":24.1218,"price":"6 \u20ac/apmeklējums","priceValue":6,"rating":4.6,"reviews":401,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Rimi+Olimpiskais+centrs+Riga"},
  {"name":"Mežaparka skrejceļš","sportKey":"running","sport":"Skriešana","city":"Rīga","address":"Mežaparks, Rīga","lat":57.0018,"lng":24.1188,"price":"Bezmaksas","priceValue":0,"rating":4.8,"reviews":620,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Mežaparka+skrejceļš"},
  {"name":"Vecāķu pludmales volejbols","sportKey":"volleyball","sport":"Pludmales volejbols","city":"Rīga","address":"Vecāķu prospekts, Rīga","lat":57.0421,"lng":24.1758,"price":"Bezmaksas","priceValue":0,"rating":4.6,"reviews":58,"verified":false,"gmaps":"https://www.google.com/maps/search/?api=1&query=Vecāķu+pludmale+Riga"},
  {"name":"Riga Cycling velotrase (Biķernieki)","sportKey":"cycling","sport":"Velosports","city":"Rīga","address":"Biķernieku trase, Rīga","lat":56.972,"lng":24.2192,"price":"10 \u20ac/dalība","priceValue":10,"rating":4.7,"reviews":132,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Biķernieku+trase"},
  {"name":"Jāņa Daliņa stadions","sportKey":"running","sport":"Vieglatlētika","city":"Rīga","address":"Aristida Briāna iela 6, Rīga","lat":56.9459,"lng":24.1517,"price":"5 \u20ac/h","priceValue":5,"rating":4.4,"reviews":74,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Jāņa+Daliņa+stadions"},
  {"name":"Sigulda Bobsleja un kamaniņu trase","sportKey":"cycling","sport":"Ekstrēmie sporti","city":"Sigulda","address":"Šveices iela 13, Sigulda","lat":57.1436,"lng":24.8446,"price":"15 \u20ac/brauciens","priceValue":15,"rating":4.8,"reviews":210,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Sigulda+Bobsleja+trase"},
  {"name":"Padel Elite Jūrmala","sportKey":"padel","sport":"Padelis","city":"Jūrmala","address":"Jomas iela 42, Jūrmala","lat":56.9686,"lng":23.7729,"price":"19 \u20ac/h","priceValue":19,"rating":4.5,"reviews":39,"verified":false,"gmaps":"https://www.google.com/maps/search/?api=1&query=Padel+Elite+Jurmala"},
  {"name":"Daugavpils Ledus halle","sportKey":"hockey","sport":"Hokejs","city":"Daugavpils","address":"18. novembra iela 66, Daugavpils","lat":55.8748,"lng":26.532,"price":"45 \u20ac/h","priceValue":45,"rating":4.3,"reviews":52,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Daugavpils+Ledus+halle"},
  {"name":"Liepājas Olimpiskais centrs","sportKey":"fitness","sport":"Fitnesa zāle","city":"Liepāja","address":"Rīgas iela 133, Liepāja","lat":56.525,"lng":21.027,"price":"30 \u20ac/mēn.","priceValue":2,"rating":4.4,"reviews":118,"verified":true,"gmaps":"https://www.google.com/maps/search/?api=1&query=Liepajas+Olimpiskais+centrs"}
];

/* ---------------- Live stats (computed from real data, nothing invented) ---------------- */
function renderHeroStats(){
  const sportsCount = new Set(VENUES.map(v=>v.sportKey)).size;
  const citiesCount = new Set(VENUES.map(v=>v.city)).size;
  document.getElementById('statVenues').textContent = VENUES.length;
  document.getElementById('statSports').textContent = sportsCount;
  document.getElementById('statCities').textContent = citiesCount;
}

/* ---------------- Map (CARTO tiles: reliable, allowed for this traffic level) ---------------- */
const PRICE_STEPS = [5,10,15,20,30,50,80,999];
let leafletMap = null;
let mapMarkers = [];
function initMap(){
  leafletMap = L.map('leafletMap', {scrollWheelZoom:false, minZoom:6, maxZoom:18}).setView([56.9496, 24.1052], 12);
  L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    subdomains: 'abcd',
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
  }).addTo(leafletMap);
  renderMap();
  setTimeout(()=>{ if(leafletMap) leafletMap.invalidateSize(); }, 250);
  window.addEventListener('resize', ()=>{ if(leafletMap) leafletMap.invalidateSize(); });
}
function starString(rating){
  const full = Math.round(rating);
  return '\u2605\u2605\u2605\u2605\u2605'.slice(0,full) + '\u2606\u2606\u2606\u2606\u2606'.slice(0,5-full);
}
function onPriceSlide(){
  const idx = Number(document.getElementById('mPrice').value);
  const val = PRICE_STEPS[idx];
  document.getElementById('priceLabel').textContent = (val >= 999 ? '80+' : val) + ' \u20ac';
}
function renderMap(){
  const sportF = document.getElementById('mSport').value;
  const cityF = document.getElementById('mCity').value;
  const idx = Number(document.getElementById('mPrice').value);
  const maxPrice = PRICE_STEPS[idx];
  const filtered = VENUES.filter(v =>
    (!sportF || v.sportKey===sportF) &&
    (!cityF || v.city===cityF) &&
    (maxPrice >= 999 || v.priceValue <= maxPrice)
  );

  document.getElementById('mapCountBadge').textContent = filtered.length + ' vietas kartē';

  mapMarkers.forEach(m => leafletMap.removeLayer(m));
  mapMarkers = [];

  filtered.forEach(v => {
    const icon = L.divIcon({
      className: '',
      html: '<div class="sport-pin ' + (v.verified ? '' : 'is-demo') + '">' + (SPORT_ICONS[v.sportKey] || '') + '</div>',
      iconSize: [32,32], iconAnchor: [16,16]
    });
    const marker = L.marker([v.lat, v.lng], {icon}).addTo(leafletMap);
    marker.bindPopup(`
      <h4>${escapeHtml(v.name)}</h4>
      <div class="p-line">${escapeHtml(v.sport)} \u00b7 ${escapeHtml(v.city)}</div>
      <div class="p-line">${starString(v.rating)} ${v.rating} (${v.reviews} atsauksmes) \u00b7 ${escapeHtml(v.price)}</div>
      <a class="pbtn" href="${v.gmaps}" target="_blank" rel="noopener">Google karte</a>
    `);
    mapMarkers.push(marker);
  });

  const listEl = document.getElementById('venueList');
  if(!filtered.length){
    listEl.innerHTML = '<div class="empty-state"><p><strong>Nekas neatbilst filtriem.</strong><br>Pamēģini citu sporta veidu, pilsētu vai augstāku cenu.</p></div>';
    return;
  }
  listEl.innerHTML = filtered.map((v) => `
    <div class="venue-card" onclick='focusVenue(${v.lat},${v.lng})'>
      <div class="venue-icon">${SPORT_ICONS[v.sportKey] || ''}</div>
      <div class="venue-info">
        <h5>${escapeHtml(v.name)}</h5>
        <div class="venue-meta">${escapeHtml(v.sport)} \u00b7 ${escapeHtml(v.address)}</div>
        <div class="venue-rating">
          <span class="stars">${starString(v.rating)}</span> ${v.rating} \u00b7 ${v.reviews} atsauksmes
          <span class="venue-tag ${v.verified ? 'verified' : 'demo'}">${v.verified ? 'Pārbaudīts' : 'Demo'}</span>
        </div>
        <div class="venue-price">${escapeHtml(v.price)}</div>
        <a class="venue-link" href="${v.gmaps}" target="_blank" rel="noopener">Atvērt Google kartē \u2192</a>
      </div>
    </div>`).join('');
}
function focusVenue(lat,lng){
  leafletMap.setView([lat,lng], 15, {animate:true});
}

/* ---------------- Product icon illustrations (inline vector art, zero network calls,
   guaranteed to render, white background, centered, never stretched or 404). ---------------- */
const PRODUCT_ICONS = {
  tennis_racket: c => `<svg viewBox="0 0 120 120"><ellipse cx="60" cy="38" rx="30" ry="34" fill="none" stroke="${c}" stroke-width="4"/><path d="M60 4 L60 72" stroke="${c}" stroke-width="4"/><path d="M40 15 L40 61 M50 8 L50 68 M70 8 L70 68 M80 15 L80 61" stroke="${c}" stroke-width="2" opacity=".55"/><path d="M32 20 L88 20 M32 38 L88 38 M32 56 L88 56" stroke="${c}" stroke-width="2" opacity=".55"/><rect x="55" y="72" width="10" height="40" rx="4" fill="${c}"/></svg>`,
  padel_racket: c => `<svg viewBox="0 0 120 120"><rect x="28" y="6" width="64" height="72" rx="30" fill="none" stroke="${c}" stroke-width="4"/><g stroke="${c}" stroke-width="2" opacity=".5"><circle cx="60" cy="42" r="6"/><circle cx="44" cy="30" r="6"/><circle cx="76" cy="30" r="6"/><circle cx="44" cy="54" r="6"/><circle cx="76" cy="54" r="6"/></g><rect x="53" y="78" width="14" height="36" rx="5" fill="${c}"/></svg>`,
  disc_golf: c => `<svg viewBox="0 0 120 120"><ellipse cx="60" cy="66" rx="46" ry="16" fill="${c}" opacity=".9"/><ellipse cx="60" cy="58" rx="46" ry="16" fill="none" stroke="${c}" stroke-width="4"/><ellipse cx="60" cy="58" rx="24" ry="8" fill="none" stroke="${c}" stroke-width="2" opacity=".6"/></svg>`,
  basketball: c => `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" fill="none" stroke="${c}" stroke-width="4"/><path d="M60 10 V110 M10 60 H110 M22 26 Q60 60 22 94 M98 26 Q60 60 98 94" stroke="${c}" stroke-width="3" fill="none"/></svg>`,
  football: c => `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" fill="none" stroke="${c}" stroke-width="4"/><polygon points="60,38 78,52 71,74 49,74 42,52" fill="${c}"/><path d="M60 38 L60 12 M78 52 L100 40 M71 74 L86 96 M49 74 L34 96 M42 52 L20 40" stroke="${c}" stroke-width="3"/></svg>`,
  hockey_stick: c => `<svg viewBox="0 0 120 120"><path d="M30 10 L58 92 Q60 100 70 100 L94 100" fill="none" stroke="${c}" stroke-width="6" stroke-linecap="round"/><path d="M92 92 L98 108 L74 108 Z" fill="${c}"/></svg>`,
  skates: c => `<svg viewBox="0 0 120 120"><path d="M20 70 Q20 40 46 40 L70 40 Q80 40 82 55 L86 70 Z" fill="none" stroke="${c}" stroke-width="4"/><rect x="14" y="70" width="86" height="8" rx="4" fill="${c}"/><path d="M20 78 Q60 100 100 78" fill="none" stroke="${c}" stroke-width="4"/></svg>`,
  volleyball: c => `<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" fill="none" stroke="${c}" stroke-width="4"/><path d="M60 10 Q90 35 78 60 Q90 85 60 110 M60 10 Q30 35 42 60 Q30 85 60 110" stroke="${c}" stroke-width="3" fill="none"/></svg>`,
  boxing_gloves: c => `<svg viewBox="0 0 120 120"><ellipse cx="46" cy="54" rx="30" ry="34" fill="${c}"/><rect x="60" y="70" width="26" height="34" rx="10" fill="${c}"/><path d="M30 40 h30" stroke="#fff" stroke-width="3" opacity=".5"/></svg>`,
  punching_bag: c => `<svg viewBox="0 0 120 120"><path d="M40 8 h40 l4 20 h-48 z" fill="${c}"/><rect x="34" y="28" width="52" height="80" rx="24" fill="none" stroke="${c}" stroke-width="4"/><path d="M50 40 v64 M70 40 v64" stroke="${c}" stroke-width="2" opacity=".5"/></svg>`,
  swim_goggles: c => `<svg viewBox="0 0 120 120"><circle cx="40" cy="55" r="22" fill="none" stroke="${c}" stroke-width="5"/><circle cx="80" cy="55" r="22" fill="none" stroke="${c}" stroke-width="5"/><path d="M62 55 h-4" stroke="${c}" stroke-width="5"/><path d="M20 45 Q10 55 20 66 M100 45 Q110 55 100 66" fill="none" stroke="${c}" stroke-width="4"/></svg>`,
  swimsuit: c => `<svg viewBox="0 0 120 120"><path d="M40 10 Q60 25 80 10 L86 40 Q86 90 60 108 Q34 90 34 40 Z" fill="${c}" opacity=".9"/></svg>`,
  running_shoe: c => `<svg viewBox="0 0 120 120"><path d="M14 78 Q14 60 36 58 L70 50 Q86 44 100 54 Q108 60 104 72 L100 80 L18 84 Z" fill="${c}"/><path d="M36 58 L40 40 M55 54 L60 38 M74 50 L78 36" stroke="${c}" stroke-width="3" opacity=".6"/></svg>`,
  gps_watch: c => `<svg viewBox="0 0 120 120"><rect x="38" y="34" width="44" height="52" rx="12" fill="none" stroke="${c}" stroke-width="5"/><rect x="50" y="14" width="20" height="20" rx="4" fill="${c}"/><rect x="50" y="86" width="20" height="20" rx="4" fill="${c}"/><circle cx="60" cy="60" r="12" fill="none" stroke="${c}" stroke-width="3"/><path d="M60 60 L60 50" stroke="${c}" stroke-width="3"/></svg>`,
  bike: c => `<svg viewBox="0 0 120 120"><circle cx="30" cy="86" r="20" fill="none" stroke="${c}" stroke-width="4"/><circle cx="90" cy="86" r="20" fill="none" stroke="${c}" stroke-width="4"/><path d="M30 86 L54 44 H80 M30 86 L64 60 L90 86 M54 44 L44 30 H36" stroke="${c}" stroke-width="4" fill="none" stroke-linecap="round"/></svg>`,
  helmet: c => `<svg viewBox="0 0 120 120"><path d="M20 78 Q20 24 60 24 Q100 24 100 78 Z" fill="none" stroke="${c}" stroke-width="5"/><path d="M20 78 h80" stroke="${c}" stroke-width="4"/><path d="M36 78 Q36 50 60 48 Q84 50 84 78" stroke="${c}" stroke-width="2" opacity=".5" fill="none"/></svg>`,
  yoga_mat: c => `<svg viewBox="0 0 120 120"><rect x="16" y="20" width="88" height="80" rx="10" fill="none" stroke="${c}" stroke-width="5"/><path d="M16 34 h88 M16 86 h88" stroke="${c}" stroke-width="2" opacity=".5"/></svg>`
};
function productIconSvg(iconKey, brand){
  const colors = {Wilson:'#8f3412', Head:'#2f4a3a', Adidas:'#201d17', Babolat:'#8f3412',
    Innova:'#a8791f', Discmania:'#2f4a3a', Discraft:'#b5451c', Spalding:'#8f3412', CCM:'#1c2b3a',
    Bauer:'#4a6a8f', Mikasa:'#2f4a3a', Venum:'#5a1f1f', Everlast:'#5a1f1f', Speedo:'#1f5a6a',
    Arena:'#1f5a6a', Nike:'#201d17', Garmin:'#1f5a6a', Trek:'#b5451c', Giro:'#2f4a3a', Casall:'#4a3a2f'};
  const c = colors[brand] || '#3a352b';
  const fn = PRODUCT_ICONS[iconKey] || PRODUCT_ICONS.tennis_racket;
  return fn(c);
}

/* ---------------- Shop / products / cart / checkout ---------------- */
const PRODUCTS = [
  {"name":"Wilson Pro Staff 97 v14 tenisa rakete","brand":"Wilson","sport":"Teniss","price":259.0,"old":289.0,"icon":"tennis_racket","desc":"Profesionāla līmeņa rakete, 97 kv. tolli, 315g."},
  {"name":"Head Radical MP tenisa rakete","brand":"Head","sport":"Teniss","price":219.0,"old":null,"icon":"tennis_racket","desc":"Universāla rakete vidēja līmeņa spēlētājiem."},
  {"name":"Adidas Adipower Padel 3.3 rakete","brand":"Adidas","sport":"Padelis","price":179.0,"old":209.0,"icon":"padel_racket","desc":"Diamond forma, augsta jauda uzbrukumam."},
  {"name":"Babolat Technical Viper padel rakete","brand":"Babolat","sport":"Padelis","price":159.0,"old":null,"icon":"padel_racket","desc":"Round forma iesācējiem un kontroles cienītājiem."},
  {"name":"Innova Star Destroyer disku golfa disks","brand":"Innova","sport":"Disku golfs","price":19.9,"old":null,"icon":"disc_golf","desc":"Distanču draiveris, populārākais modelis pasaulē."},
  {"name":"Discraft Buzzz midrange disks","brand":"Discraft","sport":"Disku golfs","price":18.5,"old":null,"icon":"disc_golf","desc":"Pasaulē vispārdotākais midrange disks, stabils lidojums."},
  {"name":"Wilson Evolution basketbola bumba","brand":"Wilson","sport":"Basketbols","price":54.9,"old":null,"icon":"basketball","desc":"Oficiālā NCAA spēles bumba, izmērs 7."},
  {"name":"Spalding TF-1000 basketbola bumba","brand":"Spalding","sport":"Basketbols","price":49.9,"old":59.9,"icon":"basketball","desc":"Kompozītmateriāla āra un telpu bumba."},
  {"name":"Nike Strike futbola bumba","brand":"Nike","sport":"Futbols","price":34.9,"old":null,"icon":"football","desc":"Treniņu bumba, izmērs 5, laba forma un noturība."},
  {"name":"CCM Tacks AS-580 hokeja nūja","brand":"CCM","sport":"Hokejs","price":149.0,"old":179.0,"icon":"hockey_stick","desc":"Vidēja izliekuma nūja pieaugušajiem."},
  {"name":"Bauer Supreme M5 Pro slidas","brand":"Bauer","sport":"Hokejs","price":479.0,"old":null,"icon":"skates","desc":"Augstākā līmeņa hokeja slidas."},
  {"name":"Mikasa V200W volejbola bumba","brand":"Mikasa","sport":"Volejbols","price":64.9,"old":null,"icon":"volleyball","desc":"Oficiālā FIVB spēles bumba."},
  {"name":"Venum Challenger 3.0 boksa cimdi","brand":"Venum","sport":"Bokss / MMA","price":54.9,"old":64.9,"icon":"boxing_gloves","desc":"14oz cimdi treniņiem un sparingam."},
  {"name":"Everlast Pro Style boksa maiss","brand":"Everlast","sport":"Bokss / MMA","price":89.0,"old":null,"icon":"punching_bag","desc":"100 cm piekaramais boksa maiss."},
  {"name":"Speedo Fastskin peldbrilles","brand":"Speedo","sport":"Peldēšana","price":34.9,"old":null,"icon":"swim_goggles","desc":"Sacensību līmeņa peldbrilles, pret aizsvīšanu."},
  {"name":"Arena Powerskin peldkostīms","brand":"Arena","sport":"Peldēšana","price":74.9,"old":89.9,"icon":"swimsuit","desc":"Treniņu peldkostīms, hlora izturīgs materiāls."},
  {"name":"Nike Pegasus 41 skriešanas apavi","brand":"Nike","sport":"Skriešana","price":149.99,"old":null,"icon":"running_shoe","desc":"Universāli skriešanas apavi ceļa distancēm."},
  {"name":"Garmin Forerunner 265 skriešanas pulkstenis","brand":"Garmin","sport":"Skriešana","price":399.0,"old":449.0,"icon":"gps_watch","desc":"GPS pulkstenis ar pulsa un VO2max mērījumiem."},
  {"name":"Trek Marlin 7 kalnu velosipēds","brand":"Trek","sport":"Velosports","price":899.0,"old":999.0,"icon":"bike","desc":"Alumīnija rāmis, hidrauliskās diska bremzes."},
  {"name":"Giro Syntax velo ķivere","brand":"Giro","sport":"Velosports","price":119.0,"old":null,"icon":"helmet","desc":"MIPS aizsardzība, 25 ventilācijas atveres."},
  {"name":"Casall Yoga Mat Balance 4mm","brand":"Casall","sport":"Fitnesa zāle","price":39.9,"old":null,"icon":"yoga_mat","desc":"Neslīdošs jogas paklājs treniņiem un stiepšanai."}
];

let CART = safeGet('sb_cart', []);
function saveCart(){ safeSet('sb_cart', CART); renderCartBadge(); renderCartDrawer(); }
function renderCartBadge(){
  const count = CART.reduce((s,i)=>s+i.qty,0);
  document.getElementById('cartCount').textContent = count;
}
function addToCart(idx){
  const p = PRODUCTS[idx];
  const existing = CART.find(i => i.idx === idx);
  if(existing) existing.qty += 1;
  else CART.push({idx, qty:1});
  saveCart();
  showToast('Pievienots grozam: ' + p.name);
}
function removeFromCart(idx){
  CART = CART.filter(i => i.idx !== idx);
  saveCart();
}
function renderCartDrawer(){
  const el = document.getElementById('cartItems');
  if(!CART.length){
    el.innerHTML = '<div class="empty-state"><p><strong>Grozs tukšs.</strong><br>Apskati veikalu un pievieno kādu preci.</p></div>';
  } else {
    el.innerHTML = CART.map(i => {
      const p = PRODUCTS[i.idx];
      return `<div class="cart-item">
        <img src="data:image/svg+xml;utf8,${encodeURIComponent(productIconSvg(p.icon, p.brand))}" alt="${escapeHtml(p.name)}">
        <div><h5>${escapeHtml(p.name)}</h5><span>${i.qty} \u00d7 ${euro(p.price)}</span></div>
        <button class="cart-remove" onclick="removeFromCart(${i.idx})" aria-label="Noņemt">\u2715</button>
      </div>`;
    }).join('');
  }
  const total = CART.reduce((s,i)=> s + PRODUCTS[i.idx].price * i.qty, 0);
  document.getElementById('cartTotal').textContent = euro(total);
}
function toggleCart(open){
  document.getElementById('cartDrawer').classList.toggle('open', open);
  document.getElementById('scrim').classList.toggle('show', open);
}

function renderShop(){
  const sportSel = document.getElementById('pSport');
  if(sportSel.options.length <= 1){
    const sports = [...new Set(PRODUCTS.map(p=>p.sport))];
    sports.forEach(s => sportSel.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`));
  }
  const sportF = sportSel.value;
  const sort = document.getElementById('pSort').value;
  let list = PRODUCTS.map((p,idx)=>({...p, idx})).filter(p => !sportF || p.sport === sportF);
  if(sort === 'price_asc') list.sort((a,b)=>a.price-b.price);
  if(sort === 'price_desc') list.sort((a,b)=>b.price-a.price);

  const grid = document.getElementById('shopGrid');
  if(!list.length){ grid.innerHTML = '<div class="empty-state"><p><strong>Nekas neatbilst filtram.</strong></p></div>'; return; }
  grid.innerHTML = list.map(p => `
    <div class="product-card">
      <div class="product-photo">${productIconSvg(p.icon, p.brand)}</div>
      <div class="product-body">
        <div class="brand-row"><span>${escapeHtml(p.brand)}</span></div>
        <h4>${escapeHtml(p.name)}</h4>
        <p class="p-desc">${escapeHtml(p.desc)}</p>
        <div class="price-row">
          <span class="price-now">${euro(p.price)}</span>
          ${p.old ? `<span class="price-old">${euro(p.old)}</span>` : ''}
        </div>
        <div class="product-actions">
          <button class="btn btn-outline" onclick="addToCart(${p.idx})">Ielikt grozā</button>
          <button class="btn btn-solid" onclick="addToCart(${p.idx}); openCheckout();">Pirkt tagad</button>
        </div>
      </div>
    </div>`).join('');
}

function openCheckout(){
  toggleCart(false);
  document.getElementById('checkoutStep1').style.display = 'block';
  document.getElementById('checkoutStep2').style.display = 'none';
  document.getElementById('checkoutStep3').style.display = 'none';
  openModal('checkoutModal');
}
function backToStep1(){
  document.getElementById('checkoutStep1').style.display = 'block';
  document.getElementById('checkoutStep2').style.display = 'none';
}
function reviewOrder(){
  const name = document.getElementById('coName').value.trim();
  const email = document.getElementById('coEmail').value.trim();
  const addr = document.getElementById('coAddr').value.trim();
  if(!name || !addr || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
    showToast('Aizpildi vārdu, derīgu e-pastu un adresi.');
    return;
  }
  if(!CART.length){ showToast('Grozs tukšs, pievieno preci pirms kases.'); return; }
  const deliveryPrices = {omniva:2.99, courier:4.99, pickup:0};
  const delivery = document.getElementById('coDelivery').value;
  const pay = document.getElementById('coPay').value;
  const subtotal = CART.reduce((s,i)=> s + PRODUCTS[i.idx].price * i.qty, 0);
  const shipCost = deliveryPrices[delivery];
  const total = subtotal + shipCost;
  const deliveryLabel = {omniva:'Omniva pakomāts', courier:'Kurjers līdz durvīm', pickup:'Izņemt veikalā'}[delivery];
  const payLabel = {card:'Bankas karte', banklink:'Internetbanka', cash:'Skaidra nauda pie kurjera'}[pay];

  document.getElementById('orderSummary').innerHTML = `
    ${CART.map(i => `<div class="order-line"><span>${escapeHtml(PRODUCTS[i.idx].name)} \u00d7 ${i.qty}</span><span>${euro(PRODUCTS[i.idx].price*i.qty)}</span></div>`).join('')}
    <div class="order-line"><span>Piegāde (${deliveryLabel})</span><span>${euro(shipCost)}</span></div>
    <div class="order-line"><span>Apmaksa</span><span>${payLabel}</span></div>
    <div class="order-line" style="font-weight:800;border-bottom:none;"><span>Kopā</span><span>${euro(total)}</span></div>
    <div class="order-line" style="border-bottom:none;"><span>Piegādes adrese</span><span>${escapeHtml(addr)}</span></div>
  `;
  document.getElementById('checkoutStep1').style.display = 'none';
  document.getElementById('checkoutStep2').style.display = 'block';
}
function confirmOrder(){
  const orderNum = 'SB-' + Math.floor(100000 + Math.random()*899999);
  document.getElementById('orderNum').textContent = orderNum;
  document.getElementById('checkoutStep2').style.display = 'none';
  document.getElementById('checkoutStep3').style.display = 'block';
  CART = []; saveCart();
}

/* ---------------- Direct messages (simulated responses) ---------------- */
const DM_CONTACTS = [
  {name:"Kārlis Ozols", sport:"Teniss", city:"Rīga"},
  {name:"Elīna Kalniņa", sport:"Padelis", city:"Rīga"},
  {name:"Roberts Jansons", sport:"Basketbols", city:"Jūrmala"},
  {name:"Anna Liepa", sport:"Skriešana", city:"Rīga"},
  {name:"Mareks Bērziņš", sport:"Bokss / MMA", city:"Rīga"}
];
let activeDM = 0;
const DM_HISTORY = DM_CONTACTS.map(()=>[]);

function initDM(){
  const list = document.getElementById('chatList');
  list.innerHTML = DM_CONTACTS.map((c,i) => `
    <div class="chat-list-item ${i===0?'active':''}" onclick="openDM(${i})" id="dmItem${i}">
      <div class="avatar">${c.name[0]}</div>
      <div><div class="chat-name">${escapeHtml(c.name)}</div><div class="chat-sport">${escapeHtml(c.sport)} \u00b7 ${escapeHtml(c.city)}</div></div>
    </div>`).join('');
  openDM(0);
}
function openDM(i){
  activeDM = i;
  document.querySelectorAll('.chat-list-item').forEach((el,idx)=> el.classList.toggle('active', idx===i));
  const c = DM_CONTACTS[i];
  document.getElementById('chatHead').textContent = c.name + ' \u00b7 ' + c.sport;
  if(!DM_HISTORY[i].length){
    DM_HISTORY[i].push({from:'them', text:'Sveiks! Redzēju, ka arī spēlē ' + c.sport.toLowerCase() + ' ' + c.city + '. Vai vēlies satrenēties šonedēļ?'});
  }
  renderDM();
}
function renderDM(){
  const body = document.getElementById('chatBody');
  body.innerHTML = DM_HISTORY[activeDM].map(m => `<div class="bubble ${m.from==='me'?'me':'them'}">${escapeHtml(m.text)}</div>`).join('');
  body.scrollTop = body.scrollHeight;
}
function dmReply(contact, userText){
  const t = userText.toLowerCase();
  if(/laik|kad|rīt|šodien|nedēļ/.test(t)) return 'Man derētu otrdien vai ceturtdien ap 18:00, ' + contact.city + ' pusē. Tev kā?';
  if(/cena|maksā|eur/.test(t)) return 'Laukuma noma parasti iznāk ap 20 eiro stundā, dalām uz pusēm, tā ir godīgi.';
  if(/vieta|kur|zāl|laukum/.test(t)) return 'Varam tikties kartes sadaļā redzamajā laukumā ' + contact.city + ', tas ir tuvākais un ar labiem vērtējumiem.';
  if(/līmen|pieredz/.test(t)) return 'Esmu vidējā vai pieredzējuša līmenī, spēlēju regulāri. Der arī, ja tu esi tikko sācis.';
  if(/sveik|labdien|čau/.test(t)) return 'Sveiks! Priecājos, ka atrakstīji.';
  if(/paldies/.test(t)) return 'Nav problēmu! Tiksimies treniņā.';
  return 'Skan labi! Rakstīšu, tiklīdz zināšu precīzu laiku. Šī saruna ir demo, bet reālā versijā te būtu īsti lietotāji ar push paziņojumiem.';
}
function sendDM(e){
  e.preventDefault();
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if(!text) return;
  DM_HISTORY[activeDM].push({from:'me', text});
  renderDM();
  input.value = '';
  const contact = DM_CONTACTS[activeDM];
  setTimeout(()=>{
    DM_HISTORY[activeDM].push({from:'them', text: dmReply(contact, text)});
    renderDM();
  }, 700 + Math.random()*600);
}

/* ---------------- Chatbot (rule-based, site-aware) ---------------- */
const BOT_KB = [
  {k:/sloga|nosaukum|kas ir sportabiedrs/i, a:'SportaBiedrs.lv ir sporta partneru un vietu platforma Latvijā. Mērķis ir palīdzēt atrast treniņu biedru, zāli un ekipējumu vienuviet.'},
  {k:/biedr|partner|atrast.*(cilvēk|spēlēt)/i, a:'Sadaļā "Atrast biedru" izvēlies sporta veidu, pilsētu un līmeni, tad spied "Meklēt", parādīsies pieejamie profili. Šie ir demo dati, reālai datubāzei vajadzīgs serveris.'},
  {k:/kart|zāl|laukum|padel|hall/i, a:'Sadaļā "Karte" ir zāles un laukumi visā Latvijā ar cenu, vērtējumu un saiti uz Google kartēm. Filtrē pēc sporta veida, pilsētas vai cenas augšpusē.'},
  {k:/veikal|shop|prece|pirkt|cena.*(rakete|bumb|disk)/i, a:'Sadaļā "Veikals" ir preces no reāliem zīmoliem (Wilson, Nike, Garmin, Trek, Innova un citiem) ar reālistiskām EUR cenām. Var filtrēt pēc sporta veida un kārtot pēc cenas.'},
  {k:/groz|cart/i, a:'Grozs ir pieejams augšējā labajā stūrī (ikona ar skaitli). Tur redzi izvēlētās preces un kopējo summu, un vari doties uz kasi.'},
  {k:/kas[ei]|checkout|apmaks|piegād/i, a:'Kasē ievadi vārdu, e-pastu un adresi, izvēlies piegādes veidu (Omniva, kurjers vai izņemšana veikalā) un apmaksas veidu, pēc tam apstiprini pasūtījumu. Šī ir demo kase, reāla apmaksa netiek veikta.'},
  {k:/ziņ|čat|message|dm|sarakst/i, a:'Sadaļā "Ziņas" vari sarakstīties ar demo partneriem, viņi automātiski atbild, lai parādītu, kā izskatītos reāla tērzēšana.'},
  {k:/sīkdatn|cookie/i, a:'Sīkdatņu prasību var apstiprināt lapas lejasdaļā redzamajā joslā: "Pieņemt visas", "Atļaut tikai nepieciešamās" vai atvērt "Iestatījumus". Izvēli var mainīt jebkurā laikā, spiežot "Sīkdatnes" kājenē.'},
  {k:/reģistr|register|konts/i, a:'Reģistrēties vai ienākt var no augšējā labā stūra pogām. Šī ir demo forma, reālai autentifikācijai nepieciešams serveris.'},
  {k:/demo|īsts|reāl|vibe|ai.*(taisīt|generāt)/i, a:'Šī ir demonstrācijas versija: partneru profili un tērzēšana ir simulēti, bet zāļu adreses, cenas un veikala preces atbilst reālam Latvijas tirgum.'},
  {k:/rīga|pilsēt|kur atrodas/i, a:'Lielākā daļa vietu ir Rīgā, bet kartē ir arī Jūrmala, Jelgava, Sigulda, Daugavpils un Liepāja.'},
  {k:/sveik|labdien|čau|hey|hi\b/i, a:'Sveiks! Ko vēlies zināt, par partneru meklēšanu, karti, veikalu, kasi vai ziņām?'},
  {k:/paldies|thanks/i, a:'Nav problēmu! Ja radīsies citi jautājumi par lapu, vienkārši uzrakstī.'}
];
function botAnswer(q){
  for(const item of BOT_KB){ if(item.k.test(q)) return item.a; }
  return 'Neesmu pilnīgi drošs, ko tieši vēlies zināt. Vari pajautāt par: partneru meklēšanu, karti un zālēm, veikalu un cenām, grozu vai kasi, ziņām vai sīkdatnēm.';
}
function toggleChatbot(){
  const panel = document.getElementById('chatbotPanel');
  const open = !panel.classList.contains('open');
  panel.classList.toggle('open', open);
  if(open && !panel.dataset.greeted){
    addBotBubble('Sveiks! Es zinu visu par šo lapu: partneriem, karti, veikalu, kasi un ziņām. Ko vēlies zināt?');
    panel.dataset.greeted = '1';
  }
}
function closeChatbotPanel(){ document.getElementById('chatbotPanel').classList.remove('open'); }
function addBotBubble(text, mine){
  const body = document.getElementById('chatbotBody');
  const div = document.createElement('div');
  div.className = 'bubble ' + (mine ? 'me' : 'them');
  div.textContent = text;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}
function sendBotMsg(e){
  e.preventDefault();
  const input = document.getElementById('chatbotInput');
  const q = input.value.trim();
  if(!q) return;
  addBotBubble(q, true);
  input.value = '';
  setTimeout(()=> addBotBubble(botAnswer(q), false), 400);
}

/* ---------------- Scroll effects ---------------- */
window.addEventListener('scroll', ()=>{
  document.getElementById('backToTop').classList.toggle('visible', window.scrollY > 500);
});

/* ---------------- Global error safety net: never leave the page half-broken ---------------- */
window.addEventListener('error', (e)=>{ console.warn('SportaBiedrs: neapstrādāta kļūda pieķerta drošības tīklā', e.error || e.message); });

/* ---------------- Init ---------------- */
window.addEventListener('DOMContentLoaded', ()=>{
  renderHeroStats();
  initCookieBanner();
  findPartners();
  try{ initMap(); }catch(err){ console.warn('Karte neielādējās:', err); }
  renderShop();
  renderCartBadge();
  renderCartDrawer();
  initDM();
});
